﻿namespace MathSol.Interpreter.Parser.Interfaces;

internal interface IParser
{
    IAstNode Parse();
}
