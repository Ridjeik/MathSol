﻿namespace MathSol.Interpreter.Tokenizer.Interface;

internal interface IToken
{
    string Value { get; }
}