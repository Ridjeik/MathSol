﻿namespace MathSol.Parser;

public interface IParser
{
    IAstNode Parse();
}
