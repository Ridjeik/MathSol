﻿namespace MathSol.Parser;

public interface IAstNode
{

}
