﻿namespace MathSol.Interpreter.Executor
{
    public class Class1
    {

    }
}
